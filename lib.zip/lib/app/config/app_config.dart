class AppConfig {
  static const String baseUrl = "http://103.217.145.53:5000/";
  //static const String baseUrl = "http://localhost:8080/api/";
  static const String username = "m0n1tor_st4tion";
  static const String password = "H1gertech.1dua3";
}
